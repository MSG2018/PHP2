

<?php


$connInfo = array('connectionName:jad.infusionsoft.com:3464980971db56ef980086c880e64bf6:This is the connection for jad.infusionsoft.com');



?>
